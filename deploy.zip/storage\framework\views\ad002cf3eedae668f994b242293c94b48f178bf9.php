

<?php $__env->startSection('header'); ?>
    <h2 class="font-semibold text-xl text-brand-800 leading-tight"><?php echo e(isset($user) ? 'Editar Usuário' : 'Novo Usuário'); ?></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="py-6">
    <div class="max-w-2xl mx-auto sm:px-6 lg:px-8">
        <div class="card-pastel">
            <form method="POST" action="<?php echo e(isset($user) ? route('admin.users.update', $user) : route('admin.users.store')); ?>">
                <?php echo csrf_field(); ?>
                <?php if(isset($user)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-brand-700">Nome</label>
                    <input type="text" name="name" value="<?php echo e(old('name', $user->name ?? '')); ?>" required class="input-pastel">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-brand-700">E-mail</label>
                    <input type="email" name="email" value="<?php echo e(old('email', $user->email ?? '')); ?>" required class="input-pastel">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-brand-700">Senha<?php echo e(isset($user) ? ' (deixe em branco para manter)' : ''); ?></label>
                    <input type="password" name="password" <?php echo e(isset($user) ? '' : 'required'); ?> class="input-pastel">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-brand-700">Telefone</label>
                    <input type="text" name="phone" value="<?php echo e(old('phone', $user->phone ?? '')); ?>" maxlength="20" class="input-pastel">
                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-brand-700">Função</label>
                    <select name="role" required class="input-pastel">
                        <option value="admin" <?php echo e(old('role', $user->role ?? '') == 'admin' ? 'selected' : ''); ?>>Admin</option>
                        <option value="attendant" <?php echo e(old('role', $user->role ?? '') == 'attendant' ? 'selected' : ''); ?>>Atendente</option>
                    </select>
                    <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label class="inline-flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" name="active" value="1" <?php echo e(old('active', $user->active ?? true) ? 'checked' : ''); ?> class="rounded border-brand-300 text-brand-600 shadow-sm focus:ring-brand-300">
                        <span class="text-sm text-brand-700">Ativo</span>
                    </label>
                </div>

                <div class="flex justify-end gap-2">
                    <a href="<?php echo e(route('admin.users.index')); ?>" class="btn-pastel-secondary">Cancelar</a>
                    <button type="submit" class="btn-pastel-primary">
                        <?php echo e(isset($user) ? 'Atualizar' : 'Salvar'); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Precode TI\Documents\GitHub\Agenda\resources\views\admin\users\edit.blade.php ENDPATH**/ ?>