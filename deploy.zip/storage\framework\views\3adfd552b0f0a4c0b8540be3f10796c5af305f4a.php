

<?php $__env->startSection('header'); ?>
    <div class="flex justify-between items-center">
        <h2 class="font-semibold text-xl text-brand-800 leading-tight">Usuários</h2>
        <a href="<?php echo e(route('admin.users.create')); ?>" class="btn-pastel-primary">+ Novo Usuário</a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="py-6">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="card-pastel p-0 overflow-hidden">
            <table class="table-pastel">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>E-mail</th>
                        <th>Telefone</th>
                        <th>Função</th>
                        <th>Ativo</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="font-medium text-stone-800"><?php echo e($u->name); ?></td>
                        <td><?php echo e($u->email); ?></td>
                        <td><?php echo e($u->phone ?? '—'); ?></td>
                        <td>
                            <span class="badge-pastel <?php echo e($u->role === 'admin' ? 'bg-brand-100 text-brand-700' : 'bg-stone-100 text-stone-600'); ?>">
                                <?php echo e($u->role === 'admin' ? 'Admin' : 'Atendente'); ?>

                            </span>
                        </td>
                        <td>
                            <span class="badge-pastel <?php echo e($u->active ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'); ?>">
                                <?php echo e($u->active ? 'Sim' : 'Não'); ?>

                            </span>
                        </td>
                        <td class="text-right space-x-2">
                            <a href="<?php echo e(route('admin.users.edit', $u)); ?>" class="text-brand-600 hover:text-brand-800 font-medium">Editar</a>
                            <?php if($u->id !== auth()->id()): ?>
                            <form method="POST" action="<?php echo e(route('admin.users.destroy', $u)); ?>" class="inline" onsubmit="return confirm('Excluir usuário?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-500 hover:text-red-700 font-medium">Excluir</button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6" class="px-4 py-8 text-center text-brand-400">Nenhum usuário cadastrado.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <div class="p-4 border-t border-brand-100">
                <?php echo e($users->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Precode TI\Documents\GitHub\Agenda\resources\views\admin\users\index.blade.php ENDPATH**/ ?>