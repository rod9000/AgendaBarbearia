

<?php $__env->startSection('header'); ?>
    <div class="flex justify-between items-center">
        <h2 class="font-semibold text-xl text-brand-800 leading-tight">Clientes</h2>
        <a href="<?php echo e(route('admin.customers.create')); ?>" class="btn-pastel-primary">+ Novo Cliente</a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="py-6">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="card-pastel p-0 overflow-hidden">
            <div class="p-4 border-b border-brand-100 bg-brand-50/30">
                <form method="GET" class="flex gap-2">
                    <input type="text" name="search" placeholder="Buscar por nome, CPF ou telefone..." value="<?php echo e(request('search')); ?>" class="input-pastel flex-1">
                    <button type="submit" class="btn-pastel-secondary">Buscar</button>
                </form>
            </div>

            <table class="table-pastel">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>CPF</th>
                        <th>Telefone</th>
                        <th>Nascimento</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="font-medium text-gray-800"><?php echo e($c->name); ?></td>
                        <td><?php echo e($c->cpf); ?></td>
                        <td><?php echo e($c->phone); ?></td>
                        <td><?php echo e($c->birth_date->format('d/m/Y')); ?></td>
                        <td class="text-right space-x-2">
                            <a href="<?php echo e(route('admin.customers.edit', $c)); ?>" class="text-brand-600 hover:text-brand-800 font-medium">Editar</a>
                            <form method="POST" action="<?php echo e(route('admin.customers.destroy', $c)); ?>" class="inline" onsubmit="return confirm('Excluir cliente? Os agendamentos vinculados também serão removidos.')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-rose-500 hover:text-rose-700 font-medium">Excluir</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="px-4 py-8 text-center text-brand-400">Nenhum cliente cadastrado.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <div class="p-4 border-t border-brand-100">
                <?php echo e($customers->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Precode TI\Documents\GitHub\Agenda\resources\views\admin\customers\index.blade.php ENDPATH**/ ?>