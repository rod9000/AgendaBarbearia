

<?php $__env->startSection('header'); ?>
    <div class="flex justify-between items-center">
        <h2 class="font-semibold text-xl text-brand-800 leading-tight">Procedimentos</h2>
        <a href="<?php echo e(route('admin.services.create')); ?>" class="btn-pastel-primary">+ Novo Procedimento</a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="py-6">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="card-pastel p-0 overflow-hidden">
            <table class="table-pastel">
                <thead>
                    <tr>
                        <th>Procedimento</th>
                        <th>Duração</th>
                        <th>Valor</th>
                        <th>Ativo</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <span class="inline-block w-3 h-3 rounded-full mr-2 shadow-sm" style="background: <?php echo e($s->color_hex); ?>"></span>
                            <span class="font-medium text-gray-800"><?php echo e($s->name); ?></span>
                        </td>
                        <td><?php echo e($s->duration_min); ?> min</td>
                        <td class="text-emerald-700 font-medium">R$ <?php echo e(number_format($s->price, 2, ',', '.')); ?></td>
                        <td><?php echo e($s->active ? 'Sim' : 'Não'); ?></td>
                        <td class="text-right space-x-2">
                            <a href="<?php echo e(route('admin.services.edit', $s)); ?>" class="text-brand-600 hover:text-brand-800 font-medium">Editar</a>
                            <form method="POST" action="<?php echo e(route('admin.services.destroy', $s)); ?>" class="inline" onsubmit="return confirm('Excluir procedimento? As agendas vinculadas também serão removidas.')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-rose-500 hover:text-rose-700 font-medium">Excluir</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="px-4 py-8 text-center text-brand-400">Nenhum procedimento cadastrado.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <div class="p-4 border-t border-brand-100">
                <?php echo e($services->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Precode TI\Documents\GitHub\Agenda\resources\views\admin\services\index.blade.php ENDPATH**/ ?>