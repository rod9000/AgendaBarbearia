

<?php $__env->startSection('header'); ?>
    <div class="flex justify-between items-center">
        <h2 class="font-semibold text-xl text-brand-800 leading-tight">Produtos</h2>
        <a href="<?php echo e(route('admin.products.create')); ?>" class="btn-pastel-primary">+ Novo Produto</a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="py-6">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="card-pastel p-0 overflow-hidden">
            <table class="table-pastel">
                <thead>
                    <tr>
                        <th>Produto</th>
                        <th>Marca</th>
                        <th>Validade</th>
                        <th>Valor Pago</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="font-medium text-stone-800"><?php echo e($p->name); ?></td>
                        <td><?php echo e($p->brand ?? '—'); ?></td>
                        <td><?php echo e($p->expiry_date ? $p->expiry_date->format('d/m/Y') : '—'); ?></td>
                        <td class="text-emerald-700 font-medium">R$ <?php echo e(number_format($p->purchase_price, 2, ',', '.')); ?></td>
                        <td class="text-right space-x-2">
                            <a href="<?php echo e(route('admin.products.edit', $p)); ?>" class="text-brand-600 hover:text-brand-800 font-medium">Editar</a>
                            <form method="POST" action="<?php echo e(route('admin.products.destroy', $p)); ?>" class="inline" onsubmit="return confirm('Excluir produto?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-500 hover:text-red-700 font-medium">Excluir</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="px-4 py-8 text-center text-brand-400">Nenhum produto cadastrado.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <div class="p-4 border-t border-brand-100">
                <?php echo e($products->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Precode TI\Documents\GitHub\Agenda\resources\views\admin\products\index.blade.php ENDPATH**/ ?>