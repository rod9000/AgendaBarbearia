

<?php $__env->startSection('header'); ?>
    <?php if(session('success')): ?>
        <div class="bg-emerald-100 border border-emerald-300 text-emerald-700 px-4 py-3 rounded-xl relative mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="flex justify-between items-center">
        <h2 class="font-semibold text-xl text-brand-800 leading-tight">Dashboard</h2>
        <form method="GET" class="flex items-center gap-2">
            <select name="period" onchange="this.form.submit()" class="input-pastel text-sm">
                <option value="today" <?php echo e($period == 'today' ? 'selected' : ''); ?>>Hoje</option>
                <option value="week" <?php echo e($period == 'week' ? 'selected' : ''); ?>>Esta Semana</option>
                <option value="month" <?php echo e($period == 'month' ? 'selected' : ''); ?>>Este Mês</option>
            </select>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="py-6">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

        
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div class="card-pastel border-l-4 border-brand-400">
                <div class="text-sm font-medium text-brand-600">Atend. Hoje</div>
                <div class="mt-1 text-3xl font-semibold text-brand-900"><?php echo e($completedCount); ?></div>
            </div>
            <div class="card-pastel border-l-4 border-orange-400">
                <div class="text-sm font-medium text-orange-600">Pendentes</div>
                <div class="mt-1 text-3xl font-semibold text-orange-700"><?php echo e($pendingCount); ?></div>
            </div>
            <div class="card-pastel border-l-4 border-emerald-400">
                <div class="text-sm font-medium text-emerald-600">Faturamento</div>
                <div class="mt-1 text-3xl font-semibold text-emerald-700">R$ <?php echo e(number_format($revenue, 2, ',', '.')); ?></div>
            </div>
            <div class="card-pastel border-l-4 border-rose-400">
                <div class="text-sm font-medium text-rose-500">Aniversariantes</div>
                <div class="mt-1 text-3xl font-semibold text-rose-600"><?php echo e($birthdayCount); ?></div>
            </div>
        </div>

        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div class="card-pastel text-center">
                <div class="text-xs font-semibold uppercase tracking-wider text-brand-500">Receita Hoje</div>
                <div class="mt-2 text-2xl font-bold text-brand-800">R$ <?php echo e(number_format($revenueDay, 2, ',', '.')); ?></div>
                <div class="mt-1 text-sm text-brand-500"><?php echo e($countDay); ?> concluído(s)</div>
            </div>
            <div class="card-pastel text-center">
                <div class="text-xs font-semibold uppercase tracking-wider text-brand-500">Receita Semana</div>
                <div class="mt-2 text-2xl font-bold text-brand-800">R$ <?php echo e(number_format($revenueWeek, 2, ',', '.')); ?></div>
                <div class="mt-1 text-sm text-brand-500"><?php echo e($countWeek); ?> concluído(s)</div>
            </div>
            <div class="card-pastel text-center">
                <div class="text-xs font-semibold uppercase tracking-wider text-brand-500">Receita Mês</div>
                <div class="mt-2 text-2xl font-bold text-brand-800">R$ <?php echo e(number_format($revenueMonth, 2, ',', '.')); ?></div>
                <div class="mt-1 text-sm text-brand-500"><?php echo e($countMonth); ?> concluído(s)</div>
            </div>
        </div>

        
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <div class="card-pastel">
                <h3 class="text-lg font-semibold text-brand-800 mb-4">Faturamento - <?php echo e(ucfirst($period)); ?></h3>
                <canvas id="revenueChart" height="200"></canvas>
            </div>

            <div class="card-pastel">
                <h3 class="text-lg font-semibold text-brand-800 mb-4">Atendimentos de Hoje</h3>
                <?php if($todayAppointments->count() > 0): ?>
                    <ul class="divide-y divide-brand-100">
                        <?php $__currentLoopData = $todayAppointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="py-3 flex justify-between items-center">
                            <div>
                                <span class="font-semibold text-brand-700"><?php echo e($app->start->format('H:i')); ?></span>
                                <span class="ml-2 text-stone-700"><?php echo e($app->customer->name); ?></span>
                                <span class="text-sm text-brand-500 ml-2"><?php echo e($app->service->name); ?></span>
                            </div>
                            <span class="badge-pastel
                                <?php switch($app->status):
                                    case ('scheduled'): ?> bg-blue-100 text-blue-700 <?php break; ?>
                                    <?php case ('confirmed'): ?> bg-emerald-100 text-emerald-700 <?php break; ?>
                                    <?php case ('in_progress'): ?> bg-brand-100 text-brand-700 <?php break; ?>
                                    <?php case ('completed'): ?> bg-stone-100 text-stone-700 <?php break; ?>
                                    <?php case ('cancelled'): ?> bg-red-100 text-red-700 <?php break; ?>
                                    <?php default: ?> bg-stone-100 text-stone-600
                                <?php endswitch; ?>
                            ">
                                <?php switch($app->status):
                                    case ('scheduled'): ?> Agendado <?php break; ?>
                                    <?php case ('confirmed'): ?> Confirmado <?php break; ?>
                                    <?php case ('in_progress'): ?> Em Andamento <?php break; ?>
                                    <?php case ('completed'): ?> Concluído <?php break; ?>
                                    <?php case ('cancelled'): ?> Cancelado <?php break; ?>
                                    <?php case ('no_show'): ?> Não Compareceu <?php break; ?>
                                    <?php default: ?> <?php echo e($app->status); ?>

                                <?php endswitch; ?>
                            </span>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php else: ?>
                    <p class="text-brand-400 text-center py-8">Nenhum atendimento hoje.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
new Chart(document.getElementById('revenueChart'), {
    type: 'bar',
    data: {
        labels: <?php echo json_encode(array_column($chartData, 'label'), 512) ?>,
        datasets: [{
            label: 'Faturamento (R$)',
            data: <?php echo json_encode(array_column($chartData, 'value'), 512) ?>,
            backgroundColor: ['#fbbf24', '#fcd34d', '#fde68a', '#f59e0b', '#fbbf24', '#fcd34d', '#fde68a'],
            borderRadius: 6,
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true, grid: { color: '#fef3c7' } } }
    }
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Precode TI\Documents\GitHub\Agenda\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>