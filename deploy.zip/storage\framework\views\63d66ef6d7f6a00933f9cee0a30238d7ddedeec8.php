

<?php $__env->startSection('header'); ?>
    <h2 class="font-semibold text-xl text-brand-800 leading-tight"><?php echo e(isset($service) ? 'Editar Procedimento' : 'Novo Procedimento'); ?></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="py-6">
    <div class="max-w-2xl mx-auto sm:px-6 lg:px-8">
        <div class="card-pastel">
            <form method="POST" action="<?php echo e(isset($service) ? route('admin.services.update', $service) : route('admin.services.store')); ?>">
                <?php echo csrf_field(); ?>
                <?php if(isset($service)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-brand-700">Nome do Procedimento</label>
                    <input type="text" name="name" value="<?php echo e(old('name', $service->name ?? '')); ?>" required class="input-pastel">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-rose-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <label class="block text-sm font-medium text-brand-700">Duração (minutos)</label>
                        <input type="number" name="duration_min" value="<?php echo e(old('duration_min', $service->duration_min ?? '')); ?>" required min="15" class="input-pastel">
                        <?php $__errorArgs = ['duration_min'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-rose-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-brand-700">Valor (R$)</label>
                        <input type="number" step="0.01" name="price" value="<?php echo e(old('price', $service->price ?? '')); ?>" required min="0" class="input-pastel">
                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-rose-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-brand-700">Cor do Calendário</label>
                    <input type="color" name="color_hex" value="<?php echo e(old('color_hex', $service->color_hex ?? '#fbbf24')); ?>" class="mt-1 h-10 w-20 rounded-lg border-brand-200 shadow-sm cursor-pointer">
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-brand-700">Estimativa do valor usado do produto (R$)</label>
                    <input type="number" step="0.01" name="estimated_product_cost" value="<?php echo e(old('estimated_product_cost', $service->estimated_product_cost ?? '')); ?>" min="0" class="input-pastel">
                    <?php $__errorArgs = ['estimated_product_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-rose-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-brand-700">Descrição</label>
                    <textarea name="description" rows="3" class="input-pastel"><?php echo e(old('description', $service->description ?? '')); ?></textarea>
                </div>

                <div class="mb-4">
                    <label class="inline-flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" name="active" value="1" <?php echo e(old('active', $service->active ?? true) ? 'checked' : ''); ?> class="rounded border-brand-300 text-brand-600 shadow-sm focus:ring-brand-300">
                        <span class="text-sm text-brand-700">Ativo</span>
                    </label>
                </div>

                <div class="flex justify-end gap-2">
                    <a href="<?php echo e(route('admin.services.index')); ?>" class="btn-pastel-secondary">Cancelar</a>
                    <button type="submit" class="btn-pastel-primary">
                        <?php echo e(isset($service) ? 'Atualizar' : 'Salvar'); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Precode TI\Documents\GitHub\Agenda\resources\views\admin\services\create.blade.php ENDPATH**/ ?>