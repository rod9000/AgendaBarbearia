

<?php $__env->startSection('header'); ?>
    <h2 class="font-semibold text-xl text-brand-800 leading-tight"><?php echo e(isset($product) ? 'Editar Produto' : 'Novo Produto'); ?></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="py-6">
    <div class="max-w-2xl mx-auto sm:px-6 lg:px-8">
        <div class="card-pastel">
            <form method="POST" action="<?php echo e(isset($product) ? route('admin.products.update', $product) : route('admin.products.store')); ?>">
                <?php echo csrf_field(); ?>
                <?php if(isset($product)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-brand-700">Nome do Produto</label>
                    <input type="text" name="name" value="<?php echo e(old('name', $product->name ?? '')); ?>" required class="input-pastel">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-brand-700">Marca</label>
                    <input type="text" name="brand" value="<?php echo e(old('brand', $product->brand ?? '')); ?>" class="input-pastel">
                    <?php $__errorArgs = ['brand'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-brand-700">Data de Validade</label>
                    <input type="date" name="expiry_date" value="<?php echo e(old('expiry_date', isset($product) && $product->expiry_date ? $product->expiry_date->format('Y-m-d') : '')); ?>" class="input-pastel">
                    <?php $__errorArgs = ['expiry_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-brand-700">Valor Pago (R$)</label>
                    <input type="number" step="0.01" name="purchase_price" value="<?php echo e(old('purchase_price', $product->purchase_price ?? '')); ?>" required min="0" class="input-pastel">
                    <?php $__errorArgs = ['purchase_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="flex justify-end gap-2">
                    <a href="<?php echo e(route('admin.products.index')); ?>" class="btn-pastel-secondary">Cancelar</a>
                    <button type="submit" class="btn-pastel-primary">
                        <?php echo e(isset($product) ? 'Atualizar' : 'Salvar'); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Precode TI\Documents\GitHub\Agenda\resources\views\admin\products\create.blade.php ENDPATH**/ ?>