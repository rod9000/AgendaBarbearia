

<?php $__env->startSection('header'); ?>
    <h2 class="font-semibold text-xl text-brand-800 leading-tight"><?php echo e(isset($customer) ? 'Editar Cliente' : 'Novo Cliente'); ?></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="py-6">
    <div class="max-w-2xl mx-auto sm:px-6 lg:px-8">
        <div class="card-pastel">
            <form method="POST" action="<?php echo e(isset($customer) ? route('admin.customers.update', $customer) : route('admin.customers.store')); ?>">
                <?php echo csrf_field(); ?>
                <?php if(isset($customer)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-brand-700">Nome Completo</label>
                    <input type="text" name="name" value="<?php echo e(old('name', $customer->name ?? '')); ?>" required class="input-pastel">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-rose-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-brand-700">CPF</label>
                    <input type="text" name="cpf" value="<?php echo e(old('cpf', $customer->cpf ?? '')); ?>" required maxlength="14" class="input-pastel">
                    <?php $__errorArgs = ['cpf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-rose-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-brand-700">Telefone</label>
                    <input type="text" name="phone" value="<?php echo e(old('phone', $customer->phone ?? '')); ?>" required maxlength="20" class="input-pastel">
                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-rose-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-brand-700">Data de Nascimento</label>
                    <input type="date" name="birth_date" value="<?php echo e(old('birth_date', isset($customer) ? $customer->birth_date->format('Y-m-d') : '')); ?>" required class="input-pastel">
                    <?php $__errorArgs = ['birth_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-rose-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-brand-700">E-mail</label>
                    <input type="email" name="email" value="<?php echo e(old('email', $customer->email ?? '')); ?>" class="input-pastel">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-rose-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-brand-700">Observações</label>
                    <textarea name="notes" rows="3" class="input-pastel"><?php echo e(old('notes', $customer->notes ?? '')); ?></textarea>
                </div>

                <div class="flex justify-end gap-2">
                    <a href="<?php echo e(route('admin.customers.index')); ?>" class="btn-pastel-secondary">Cancelar</a>
                    <button type="submit" class="btn-pastel-primary">
                        <?php echo e(isset($customer) ? 'Atualizar' : 'Salvar'); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Precode TI\Documents\GitHub\Agenda\resources\views\admin\customers\edit.blade.php ENDPATH**/ ?>